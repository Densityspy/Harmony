![Banner](https://nyri4.github.io/Comfy/assets/banner.png)

---

# Comfy
![Preview](https://i.ibb.co/p1JGyC6/image.png)

## 📥 Installation

### Powercord & Vizality

```sh
git clone https://github.com/NYRI4/Comfy
```

### BetterDiscord

1. Go [here](https://betterdiscord.net/ghdl?id=3503)
2. Save the file into your theme folder

## 🖌️ Customization
Go into your theme folder > Comfy > support
- For BetterDiscord : `comfy.theme.css`
- For Powercord/Vizality : `_custom.css`

## Credits

Thanks a lot to Snapperito, Harley, Tropical and others peeps that I forgot for the help !
